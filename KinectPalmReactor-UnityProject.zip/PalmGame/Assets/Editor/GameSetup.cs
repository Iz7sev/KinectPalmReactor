using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public static class GameSetup
{
    [MenuItem("Kinect Game/Create Game Scene")]
    public static void CreateScene()
    {
        var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
        var game=new GameObject("Kinect Target Game");
        game.AddComponent<TargetGame>();
        game.AddComponent<AzureKinectInput>();
        var camera=new GameObject("Main Camera").AddComponent<Camera>();
        camera.tag="MainCamera";
        camera.clearFlags=CameraClearFlags.SolidColor;
        camera.backgroundColor=Color.black;
        EditorSceneManager.SaveScene(scene,"Assets/Game.unity");
        EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene("Assets/Game.unity",true)};
        PlayerSettings.SetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Standalone,ScriptingImplementation.Mono2x);
        AssetDatabase.SaveAssets();
    }
}
