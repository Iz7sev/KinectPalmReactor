using System;
static class Tests
{
    static int count;
    static void Check(bool value,string message) { if(!value) throw new Exception(message); count++; }
    static void Main()
    {
        var m=new ShootingMatch(); m.Start(new[]{"A","B"});
        Check(!m.RecordShot(true,100),"No scoring before the round");
        m.Tick(3); Check(m.Phase==ShootingMatch.Stage.Playing&&m.Remaining==60,"Countdown does not consume play time");
        m.RecordShot(true,200); m.RecordShot(false,100);
        Check(m.Current.Score==200&&m.Current.Hits==1&&m.Current.Shots==2&&m.Current.Accuracy==50,"Score, hits, shots and accuracy");
        m.Tick(59.99); Check(m.Phase==ShootingMatch.Stage.Playing,"Round lasts the full 60 seconds");
        m.Tick(.02); Check(m.Phase==ShootingMatch.Stage.BetweenPlayers,"Round ends at 60 seconds");
        Check(!m.RecordShot(true,500),"No scoring after the bell");
        m.Tick(900); Check(m.PlayerIndex==0,"Wait for the next player to confirm readiness");
        Check(m.NextPlayer()&&m.PlayerIndex==1&&m.Remaining==60,"Next player gets an independent 60-second turn");
        m.Tick(63); Check(m.Phase==ShootingMatch.Stage.Finished,"Last player completes the match");
        Check(m.Players[0].Score==200&&m.Players[1].Score==0,"Scores remain separate");
        Check(!m.NextPlayer(),"Cannot skip after the final round");
        m.Start(new[]{"C","D"}); Check(m.Players[0].Shots==0,"Replay clears results");
        var r=new RecoilDetector();
        Check(!r.Sample(0,0,true)&&!r.Sample(.1,0,true)&&!r.Sample(.22,0,true),"Steady hand does not fire");
        Check(r.Sample(.30,-.03f,true),"Upward kick fires once");
        Check(!r.Sample(.4,-.03f,true)&&!r.Sample(.55,-.03f,true)&&!r.Sample(.7,-.03f,true),"Holding the gun up does not autofire");
        Check(!r.Sample(.8,.02f,true),"Lowering the gun does not fire");
        r.Sample(.9,.02f,true); r.Sample(1.05,.02f,true);
        Check(r.Sample(1.15,-.02f,true),"A new kick fires after rearming");
        Check(!r.Sample(2,-.5f,true),"Do not fire from a jump after a tracking gap");
        Check(!r.Sample(2.1,-.8f,false),"No fire when the gun pose disappears");
        var p=new HandPoint[21];
        p[5]=new HandPoint(1,1,0); p[6]=new HandPoint(1,2,0); p[7]=new HandPoint(1,2.5f,0); p[8]=new HandPoint(1,3,0);
        p[4]=new HandPoint(2,.5f,0);
        foreach(int b in new[]{9,13,17})
        {
            float x=(13-b)*.2f; p[b]=new HandPoint(x,1,0); p[b+1]=new HandPoint(x,1.8f,0); p[b+2]=new HandPoint(x,1.4f,0); p[b+3]=new HandPoint(x,.8f,0);
        }
        Check(GunPoseRules.IsFingerGun(p),"Extended index plus folded other fingers is a finger gun");
        p[8]=new HandPoint(1,.7f,0); Check(!GunPoseRules.IsFingerGun(p),"Closed fist is not a finger gun");
        p[8]=new HandPoint(1,3,0);
        foreach(int b in new[]{9,13,17}) p[b+3]=new HandPoint(p[b].X,3,0);
        Check(!GunPoseRules.IsFingerGun(p),"Open palm is not a finger gun");
        Check(!GunPoseRules.IsFingerGun(new HandPoint[20]),"Reject incomplete landmark sets");
        Check(GunPoseRules.IsOpenPalm(p),"Open hand enables palm blaster");
        p[8]=new HandPoint(1,.7f,0);
        Check(GunPoseRules.IsOpenPalm(p),"Palm tolerates one partly folded finger");
        p[12]=new HandPoint(p[9].X,.7f,0);
        Check(!GunPoseRules.IsOpenPalm(p),"Two extended fingers do not enable palm blaster");
        Check(!GunPoseRules.IsOpenPalm(new HandPoint[21]),"Degenerate landmarks do not enable palm blaster");
        var charge=new PalmChargeTrigger();
        Check(!charge.Tick(.2,0,true)&&!charge.Tick(.2,0,true)&&charge.Tick(.06,0,true),"Palm hold fires after charge completes");
        Check(!charge.Tick(.3,0,true)&&!charge.Tick(.3,0,true),"Laser cooldown prevents rapid repeat shots");
        charge.Reset(); charge.Tick(.3,0,true);
        Check(!charge.Tick(.2,1,true),"Changing targets starts a new charge");
        charge.Reset(); charge.Tick(.3,0,true); charge.Tick(.1,-1,false);
        Check(charge.Tick(.16,0,true),"Brief landmark loss pauses rather than loses charge");
        charge.Reset(); charge.Tick(.3,0,true); charge.Tick(.25,-1,false);
        Check(!charge.Tick(.2,0,true),"Lost hand resets charge and cannot shoot");
        charge.Reset(); charge.Tick(.3,0,true);
        Check(!charge.Tick(2,0,true)&&!charge.Tick(.2,0,true),"App stall cannot complete a charge");
        charge.Reset();
        Check(!charge.Tick(.5,0,false)&&!charge.Tick(.5,-1,true),"No firing without palm or target");
        Check(Math.Abs(ProjectionRules.Map(.1f,.8f))<.0001&&Math.Abs(ProjectionRules.Map(.9f,.8f)-1)<.0001,"Reach maps the comfortable area to screen edges");
        Check(Math.Abs(ProjectionRules.Map(.5f,.55f)-.5f)<.0001,"Reach preserves the centre");
        Check(ProjectionRules.Map(0,.8f)<0,"Outside the control area stays out of bounds instead of auto aiming");
        Check(SilhouetteRules.IsForeground(1800,3000,true,3200),"Person closer than background is visible");
        Check(!SilhouetteRules.IsForeground(2980,3000,true,3200),"Static furniture and depth noise are removed");
        Check(!SilhouetteRules.IsForeground(0,3000,true,3200)&&!SilhouetteRules.IsForeground(4000,4500,true,3200),"Invalid and distant depth are rejected");
        var leftCharge=new PalmChargeTrigger(); var rightCharge=new PalmChargeTrigger();
        leftCharge.Tick(.3,0,true); rightCharge.Tick(.1,0,true);
        Check(leftCharge.Tick(.2,0,true)&&!rightCharge.Tick(.2,0,true),"Hands charge independently");
        leftCharge.Reset();
        Check(rightCharge.Tick(.2,0,true),"Resetting one hand does not reset the other");
        Console.WriteLine("PASS: "+count+" match, pose, dual laser, projection and silhouette checks");
    }
}
