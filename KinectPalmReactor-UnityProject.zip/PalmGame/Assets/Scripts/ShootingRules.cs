using System;

public sealed class ShootingMatch
{
    public const double RoundSeconds=60;
    public enum Stage { Lobby,Countdown,Playing,BetweenPlayers,Finished }
    public sealed class Result
    {
        public string Name;
        public int Score,Hits,Shots;
        public double Accuracy => Shots==0?0:100.0*Hits/Shots;
    }
    public Stage Phase { get; private set; }=Stage.Lobby;
    public Result[] Players { get; private set; }=Array.Empty<Result>();
    public int PlayerIndex { get; private set; }
    public double Remaining { get; private set; }
    public double Countdown { get; private set; }
    public Result Current => Players.Length==0?null:Players[PlayerIndex];
    public void Start(string[] names)
    {
        if(names==null||names.Length<2||names.Length>6) throw new ArgumentException("Choose 2 to 6 players.");
        Players=new Result[names.Length];
        for(int i=0;i<names.Length;i++) Players[i]=new Result{Name=string.IsNullOrWhiteSpace(names[i])?"PLAYER "+(i+1):names[i].Trim()};
        PlayerIndex=0; BeginTurn();
    }
    void BeginTurn() { Remaining=RoundSeconds; Countdown=3; Phase=Stage.Countdown; }
    public bool NextPlayer()
    {
        if(Phase!=Stage.BetweenPlayers) return false;
        PlayerIndex++; BeginTurn(); return true;
    }
    public void Tick(double seconds)
    {
        if(double.IsNaN(seconds)||double.IsInfinity(seconds)||seconds<=0) return;
        if(Phase==Stage.Countdown)
        {
            double used=Math.Min(Countdown,seconds); Countdown-=used; seconds-=used;
            if(Countdown>0) return;
            Phase=Stage.Playing;
        }
        if(Phase!=Stage.Playing) return;
        Remaining=Math.Max(0,Remaining-seconds);
        if(Remaining<=0) Phase=PlayerIndex==Players.Length-1?Stage.Finished:Stage.BetweenPlayers;
    }
    public bool RecordShot(bool hit,int points)
    {
        if(Phase!=Stage.Playing) return false;
        Current.Shots++;
        if(hit) { Current.Hits++; Current.Score+=Math.Max(0,points); }
        return true;
    }
}

public sealed class RecoilDetector
{
    double lastTime,lastFire=-100,armedAt;
    float previousY,anchorY;
    bool havePrevious,armed;
    public float SpeedThreshold=.20f,LiftThreshold=.018f;
    public double Cooldown=.45;
    public void Reset() { havePrevious=armed=false; lastFire=-100; }
    // Chest-relative height in metres; Kinect y points downwards.
    public bool Sample(double time,float y,bool pose)
    {
        if(!pose||double.IsNaN(time)||float.IsNaN(y)||float.IsInfinity(y)) { havePrevious=armed=false; return false; }
        if(!havePrevious||time<=lastTime||time-lastTime>.6)
        {
            havePrevious=true; previousY=anchorY=y; lastTime=armedAt=time; armed=false; return false;
        }
        float speed=(float)((previousY-y)/(time-lastTime)); previousY=y; lastTime=time;
        if(Math.Abs(speed)<.12f)
        {
            if(!armed) { anchorY=y; armedAt=time; armed=true; }
            else if(time-armedAt>.35) { anchorY=y; armedAt=time-.15; }
        }
        bool fire=armed&&time-armedAt>=.10&&time-lastFire>=Cooldown&&speed>=SpeedThreshold&&anchorY-y>=LiftThreshold;
        if(fire) { lastFire=time; armed=false; }
        return fire;
    }
}

public sealed class PalmChargeTrigger
{
    const double ChargeSeconds=.45,Cooldown=.8;
    double held,cooldown,missing;
    int locked=-1;
    public float Progress => (float)Math.Min(1,held/ChargeSeconds);
    public void Reset() { held=cooldown=missing=0; locked=-1; }
    public bool Tick(double seconds,int target,bool valid)
    {
        if(double.IsNaN(seconds)||double.IsInfinity(seconds)||seconds<=0) return false;
        // Never complete a charge across an application stall.
        if(seconds>.6) { Reset(); return false; }
        cooldown=Math.Max(0,cooldown-seconds);
        if(!valid||target<0)
        {
            missing+=seconds;
            if(missing>.2) { held=0; locked=-1; }
            return false;
        }
        missing=0;
        if(target!=locked) { locked=target; held=0; }
        if(cooldown>0) return false;
        held+=seconds;
        if(held<ChargeSeconds) return false;
        held=0; cooldown=Cooldown;
        return true;
    }
}

public struct GunInput
{
    public bool Tracked,Pose;
    public uint BodyId;
    public float AimX,AimY,HandX,HandY,RelativeHandY;
    public double Timestamp;
}

public static class ProjectionRules
{
    public static float Map(float position,float span)
    {
        if(float.IsNaN(position)||float.IsInfinity(position)||span<.1f) return -1;
        return (position-(1-span)/2)/span;
    }
}

public static class SilhouetteRules
{
    public static bool IsForeground(int depth,int background,bool calibrated,int maxDepth)
        => depth>=450&&depth<=maxDepth&&(!calibrated||background==0||background-depth>=120);
}
