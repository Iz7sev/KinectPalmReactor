using System;
using System.Collections.Generic;
using UnityEngine;

public sealed class TargetGame : MonoBehaviour
{
    public bool mirror=true,mousePractice,silhouetteMode=true;
    public float controlSpan=.6f;
    const float AssistMargin=.008f;
    public float duration=60;
    readonly ShootingMatch match=new ShootingMatch();
    readonly List<Plate> plates=new List<Plate>();
    readonly List<Feedback> effects=new List<Feedback>();
    readonly List<Burst> bursts=new List<Burst>();
    AudioSource speaker;
    AudioClip laserSound,hitSound,endSound;
    Texture2D ring;
    int combo;
    float comboUntil=-100,hitFlash=-100;
    sealed class Burst { public Vector2 At; public float Born; public int Seed; }
    readonly string[] names={"PLAYER 1","PLAYER 2","PLAYER 3","PLAYER 4","PLAYER 5","PLAYER 6"};
    Texture2D cameraTexture,silhouetteTexture,disc;
    Rect imageRect;
    Vector2 mousePosition;
    sealed class HandState
    {
        public GunInput Input;
        public Vector2 Aim=new Vector2(.5f,.5f),Stable,Shot,Beam;
        public float ShotAt=-100;
        public readonly PalmChargeTrigger Charge=new PalmChargeTrigger();
    }
    readonly HandState[] hands={new HandState(),new HandState()};
    bool newInput,mouseFire,resultSaved;
    float frameAt=-100,backgroundAt=-100;
    bool backgroundCountdown;
    int playerCount=2,serial;
    System.Random random;
    string status="Kinect starting...",saveMessage="";
    sealed class Plate
    {
        public Vector2 Origin;
        public float Radius,Born,Lifetime,Phase;
        public int Points;
        public Vector2 At(float t)=>Origin+new Vector2(Mathf.Sin(t*.65f+Phase)*.045f,Mathf.Cos(t*.8f+Phase)*.025f);
    }
    sealed class Feedback { public Vector2 Position; public string Text; public Color Color; public float Until; }
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Bootstrap()
    {
        if(FindAnyObjectByType<TargetGame>()!=null) return;
        var go=new GameObject("Kinect Shooting Gallery");
        go.AddComponent<TargetGame>(); go.AddComponent<AzureKinectInput>();
    }
    void Awake()
    {
        duration=(float)ShootingMatch.RoundSeconds; Application.runInBackground=true;
        disc=new Texture2D(64,64,TextureFormat.RGBA32,false);
        for(int y=0;y<64;y++) for(int x=0;x<64;x++)
            disc.SetPixel(x,y,new Color(1,1,1,Mathf.Clamp01(32-Vector2.Distance(new Vector2(x+.5f,y+.5f),new Vector2(32,32)))));
        disc.Apply();
        ring=new Texture2D(64,64,TextureFormat.RGBA32,false);
        for(int y=0;y<64;y++) for(int x=0;x<64;x++)
        {
            float d=Vector2.Distance(new Vector2(x+.5f,y+.5f),new Vector2(32,32));
            ring.SetPixel(x,y,new Color(1,1,1,Mathf.Clamp01(2-Mathf.Abs(d-29))));
        }
        ring.Apply();
        speaker=gameObject.AddComponent<AudioSource>(); speaker.spatialBlend=0; speaker.volume=.22f;
        if(FindAnyObjectByType<AudioListener>()==null) gameObject.AddComponent<AudioListener>();
        laserSound=MakeSound("Reactor laser",.16f,0);
        hitSound=MakeSound("Drone explosion",.24f,1);
        endSound=MakeSound("Round complete",.55f,2);
    }
    AudioClip MakeSound(string title,float seconds,int kind)
    {
        const int rate=22050;
        var data=new float[Mathf.CeilToInt(seconds*rate)];
        var noise=new System.Random(100+kind);
        double phase=0;
        for(int i=0;i<data.Length;i++)
        {
            float t=(float)i/data.Length,frequency=kind==0?Mathf.Lerp(1200,180,t):kind==1?Mathf.Lerp(180,45,t):440*(1+Mathf.Floor(t*3)*.25f);
            phase+=2*Math.PI*frequency/rate;
            float sample=(float)Math.Sin(phase);
            if(kind==1) sample=sample*.25f+((float)noise.NextDouble()*2-1)*.65f;
            data[i]=sample*Mathf.Min(1,t*20)*Mathf.Pow(1-t,kind==1?2:1)*.55f;
        }
        var clip=AudioClip.Create(title,data.Length,1,rate,false); clip.SetData(data,0); return clip;
    }
    public void SetStatus(string text) { status=text; }
    public void SetFrame(byte[] pixels,int width,int height,GunInput left,GunInput right,byte[] mask)
    {
        if(cameraTexture==null||cameraTexture.width!=width||cameraTexture.height!=height)
        {
            if(cameraTexture!=null) Destroy(cameraTexture);
            cameraTexture=new Texture2D(width,height,TextureFormat.BGRA32,false);
        }
        cameraTexture.LoadRawTextureData(pixels); cameraTexture.Apply(false);
        if(mask!=null)
        {
            if(silhouetteTexture==null) silhouetteTexture=new Texture2D(320,180,TextureFormat.RGBA32,false);
            silhouetteTexture.LoadRawTextureData(mask); silhouetteTexture.Apply(false);
        }
        hands[0].Input=left; hands[1].Input=right;
        newInput=true; frameAt=Time.unscaledTime;
    }
    Vector2 Pixel(Vector2 p)=>new Vector2(imageRect.x+p.x*imageRect.width,imageRect.y+p.y*imageRect.height);
    bool InImage(Vector2 p)=>p.x>=0&&p.x<=1&&p.y>=0&&p.y<=1;
    float Elapsed=>(float)(ShootingMatch.RoundSeconds-match.Remaining);
    bool HandVisible(HandState hand)=>Time.unscaledTime-frameAt<.3f&&hand.Input.Tracked;
    bool Ready(HandState hand)=>HandVisible(hand)&&hand.Input.Pose;
    Vector2 Map(Vector2 p)=>new Vector2(ProjectionRules.Map(p.x,controlSpan),ProjectionRules.Map(p.y,controlSpan));
    void BeginTurn()
    {
        GetComponent<AzureKinectInput>()?.ResetPlayerSelection();
        random=new System.Random(20261015); serial=0; plates.Clear(); effects.Clear(); bursts.Clear(); newInput=false;
        combo=0; comboUntil=hitFlash=-100;
        foreach(var hand in hands) { hand.Charge.Reset(); hand.Stable=hand.Aim=new Vector2(.5f,.5f); hand.ShotAt=-100; }
        for(int i=0;i<6;i++) plates.Add(NewPlate(0,i));
    }
    Plate NewPlate(float t,int lane)
    {
        serial++; bool gold=serial%9==0,small=!gold&&serial%3==0;
        return new Plate{Origin=new Vector2(.18f+lane%3*.32f+(float)random.NextDouble()*.025f,.34f+lane/3*.25f),
            Radius=gold?.032f:small?.043f:.058f,Points=gold?500:small?200:100,Born=t,
            Lifetime=gold?8:12+(float)random.NextDouble()*3,Phase=(float)random.NextDouble()*Mathf.PI*2};
    }
    void Update()
    {
        float aspect=cameraTexture!=null?(float)cameraTexture.width/cameraTexture.height:16f/9;
        float w=Mathf.Min(Screen.width,Screen.height*aspect),h=w/aspect;
        imageRect=new Rect((Screen.width-w)/2,(Screen.height-h)/2,w,h);
        var previous=match.Phase; match.Tick(Time.unscaledDeltaTime);
        if(previous==ShootingMatch.Stage.Playing&&match.Phase!=previous) { foreach(var hand in hands) hand.Charge.Reset(); mouseFire=false; speaker.PlayOneShot(endSound); }
        if(backgroundCountdown&&Time.unscaledTime>=backgroundAt)
        {
            GetComponent<AzureKinectInput>()?.CaptureBackground(); backgroundCountdown=false;
        }
        if(match.Phase==ShootingMatch.Stage.Finished&&!resultSaved) SaveResults();
        for(int i=effects.Count-1;i>=0;i--) if(effects[i].Until<Time.unscaledTime) effects.RemoveAt(i);
        for(int i=bursts.Count-1;i>=0;i--) if(Time.unscaledTime-bursts[i].Born>.65f) bursts.RemoveAt(i);
        if(mousePractice)
        {
            var hand=hands[0];
            hand.Aim=new Vector2((mousePosition.x-imageRect.x)/w,(mousePosition.y-imageRect.y)/h);
            hand.Stable=hand.Aim;
            if(mouseFire) Shoot(hand); mouseFire=false;
        }
        else if(newInput)
        {
            newInput=false;
            foreach(var hand in hands)
            {
                var input=hand.Input;
                Vector2 next=Map(new Vector2(mirror?1-input.AimX:input.AimX,input.AimY));
                if(HandVisible(hand)) hand.Aim=Vector2.Distance(hand.Aim,next)>.025f?next:Vector2.Lerp(hand.Aim,next,.8f);
            }
        }
        if(!mousePractice)
        {
            foreach(var hand in hands)
            {
                hand.Stable=hand.Aim;
                bool valid=Ready(hand)&&InImage(hand.Aim)&&match.Phase==ShootingMatch.Stage.Playing;
                // Charge each palm independently, including off-target shots.
                if(hand.Charge.Tick(Time.unscaledDeltaTime,0,valid)) Shoot(hand);
            }
        }
        if(match.Phase==ShootingMatch.Stage.Playing)
            for(int i=0;i<plates.Count;i++) if(Elapsed-plates[i].Born>plates[i].Lifetime) plates[i]=NewPlate(Elapsed,i);
    }
    int FindTarget(Vector2 p,float margin)
    {
        int nearest=-1; float best=float.PositiveInfinity;
        for(int i=0;i<plates.Count;i++)
        {
            if(Elapsed-plates[i].Born<.35f) continue;
            Vector2 d=p-plates[i].At(Elapsed); d.x*=imageRect.width/imageRect.height;
            float distance=d.sqrMagnitude,radius=plates[i].Radius+margin;
            if(distance<=radius*radius&&distance<best) { nearest=i; best=distance; }
        }
        return nearest;
    }
    void Shoot(HandState hand)
    {
        Vector2 p=hand.Stable;
        if(match.Phase!=ShootingMatch.Stage.Playing||!InImage(p)) return;
        int hit=FindTarget(p,AssistMargin);
        int points=hit<0?0:plates[hit].Points;
        if(!match.RecordShot(hit>=0,points)) return;
        speaker.PlayOneShot(laserSound,.5f);
        if(hit>=0)
        {
            combo=Time.unscaledTime<=comboUntil?combo+1:1; comboUntil=Time.unscaledTime+2.5f;
            hitFlash=Time.unscaledTime;
            bursts.Add(new Burst{At=plates[hit].At(Elapsed),Born=Time.unscaledTime,Seed=serial});
            speaker.PlayOneShot(hitSound,.65f);
        }
        else { combo=0; comboUntil=-100; }
        var input=hand.Input;
        hand.Beam=mousePractice?hand.Aim:new Vector2(mirror?1-input.HandX:input.HandX,input.HandY);
        hand.Shot=p; hand.ShotAt=Time.unscaledTime;
        effects.Add(new Feedback{Position=p,Text=hit<0?"MISS":"+"+points,Color=hit<0?new Color(1,.5f,.45f):new Color(1,.9f,.2f),Until=Time.unscaledTime+.7f});
        if(hit>=0) plates[hit]=NewPlate(Elapsed,hit);
    }
    void SaveResults()
    {
        resultSaved=true;
        try
        {
            string directory=System.IO.Path.Combine(Application.persistentDataPath,"ShootingResults");
            System.IO.Directory.CreateDirectory(directory);
            var csv=new System.Text.StringBuilder("Player,Score,Hits,Shots,AccuracyPercent,Seconds\r\n");
            foreach(var p in match.Players) csv.Append('"').Append(p.Name.Replace("\"","\"\"")).Append("\",").Append(p.Score).Append(',').Append(p.Hits).Append(',').Append(p.Shots).Append(',').Append(p.Accuracy.ToString("F1",System.Globalization.CultureInfo.InvariantCulture)).Append(',').Append(ShootingMatch.RoundSeconds).Append("\r\n");
            System.IO.File.WriteAllText(System.IO.Path.Combine(directory,"match-"+DateTime.Now.ToString("yyyyMMdd-HHmmss-fff")+".csv"),csv.ToString(),new System.Text.UTF8Encoding(true));
            saveMessage="Results saved to ShootingResults";
        }
        catch(Exception e) { saveMessage="Could not save results: "+e.Message; }
    }
    void Box(Rect r,Color c) { GUI.color=c; GUI.DrawTexture(r,Texture2D.whiteTexture); GUI.color=Color.white; }
    void Circle(Vector2 p,float radius,Color c)
    {
        Vector2 q=Pixel(p); radius*=imageRect.height;
        GUI.color=c; GUI.DrawTexture(new Rect(q.x-radius,q.y-radius,radius*2,radius*2),disc); GUI.color=Color.white;
    }
    void Beam(Vector2 a,Vector2 b,float width,Color color)
    {
        Vector2 start=Pixel(a),end=Pixel(b),d=end-start;
        var matrix=GUI.matrix;
        GUIUtility.RotateAroundPivot(Mathf.Atan2(d.y,d.x)*Mathf.Rad2Deg,start);
        Box(new Rect(start.x,start.y-width/2,d.magnitude,width),color);
        GUI.matrix=matrix;
    }
    void DrawEnemy(Plate enemy,Color color,float u,int small)
    {
        Vector2 p=enemy.At(Elapsed),q=Pixel(p);
        float r=enemy.Radius*imageRect.height;
        float age=Elapsed-enemy.Born;
        if(age<.35f) { Ring(p,enemy.Radius*(.5f+age*3),new Color(color.r,color.g,color.b,1-age/.35f)); return; }
        Circle(p,enemy.Radius+AssistMargin,new Color(color.r,color.g,color.b,.18f));
        // Armoured drone: reactor core is the circular hit area; wings are decoration.
        Box(new Rect(q.x-r*.7f,q.y-r*.65f,r*1.4f,r*1.3f),new Color(.12f,.15f,.23f));
        Box(new Rect(q.x-r*.65f,q.y-r*.7f,r*1.3f,r*.2f),color);
        Box(new Rect(q.x-r*1.3f,q.y-r*.15f,r*.55f,r*.3f),color);
        Box(new Rect(q.x+r*.75f,q.y-r*.15f,r*.55f,r*.3f),color);
        Circle(p,enemy.Radius*.48f,color);
        Circle(p,enemy.Radius*.24f,new Color(1,.95f,.8f));
        Box(new Rect(q.x-r*.55f,q.y-r*.4f,r*.35f,r*.15f),Color.white);
        Box(new Rect(q.x+r*.2f,q.y-r*.4f,r*.35f,r*.15f),Color.white);
        GUI.Label(new Rect(q.x-55*u,q.y+r*.85f,110*u,26*u),enemy.Points.ToString(),Text(small,color,TextAnchor.MiddleCenter));
    }
    void Ring(Vector2 p,float radius,Color color)
    {
        Vector2 q=Pixel(p); radius*=imageRect.height;
        GUI.color=color; GUI.DrawTexture(new Rect(q.x-radius,q.y-radius,radius*2,radius*2),ring); GUI.color=Color.white;
    }
    void DrawBursts(float u)
    {
        foreach(var burst in bursts)
        {
            float age=Time.unscaledTime-burst.Born,fade=1-age/.65f;
            Ring(burst.At,.025f+age*.20f,new Color(0,.9f,1,fade));
            Ring(burst.At,.015f+age*.12f,new Color(1,.65f,.15f,fade));
            if(age<.12f) Circle(burst.At,.025f+age*.1f,new Color(1,1,.8f,(1-age/.12f)*.8f));
            for(int i=0;i<12;i++)
            {
                float angle=i*Mathf.PI*2/12+burst.Seed*.7f,speed=.12f+(i%3)*.06f;
                Vector2 delta=new Vector2(Mathf.Cos(angle)*imageRect.height/imageRect.width,Mathf.Sin(angle));
                Vector2 p=burst.At+delta*age*speed+new Vector2(0,age*age*.12f);
                Vector2 q=Pixel(p); float size=(3+i%3)*u*fade;
                Box(new Rect(q.x-size/2,q.y-size/2,size,size),new Color(1,.55f+(i%2)*.35f,.2f,fade));
            }
        }
    }
    void DrawHand(HandState hand,int index,float u,int small)
    {
        bool visible=mousePractice?index==0:HandVisible(hand);
        Color color=index==0?new Color(1,.45f,.85f):Color.cyan;
        if(visible)
        {
            Vector2 p=new Vector2(Mathf.Clamp01(hand.Stable.x),Mathf.Clamp01(hand.Stable.y)),q=Pixel(p);
            bool active=(mousePractice||Ready(hand))&&InImage(hand.Aim);
            Color cross=!active?Color.gray:FindTarget(hand.Stable,AssistMargin)>=0?Color.green:color;
            Circle(p,.016f,cross); Circle(p,.009f,new Color(.02f,.06f,.15f));
            Box(new Rect(q.x-18*u,q.y-u,36*u,2*u),cross); Box(new Rect(q.x-u,q.y-18*u,2*u,36*u),cross);
            GUI.Label(new Rect(q.x+20*u,q.y-25*u,80*u,30*u),index==0?"L":"R",Text(small,color));
            if(active&&!mousePractice&&hand.Charge.Progress>0)
            {
                Vector2 source=new Vector2(mirror?1-hand.Input.HandX:hand.Input.HandX,hand.Input.HandY);
                Circle(source,.02f+hand.Charge.Progress*.015f,new Color(color.r,color.g,color.b,.45f));
                Beam(source,hand.Stable,2*u,new Color(color.r,color.g,color.b,.3f));
                Box(new Rect(q.x-30*u,q.y+25*u,60*u,6*u),new Color(.02f,.06f,.15f));
                Box(new Rect(q.x-30*u,q.y+25*u,60*u*hand.Charge.Progress,6*u),color);
            }
        }
        float age=Time.unscaledTime-hand.ShotAt;
        if(age<.25f)
        {
            float fade=1-age/.25f;
            Beam(hand.Beam,hand.Shot,18*u,new Color(color.r,color.g,color.b,.3f*fade));
            Beam(hand.Beam,hand.Shot,7*u,new Color(color.r,color.g,color.b,fade));
            Beam(hand.Beam,hand.Shot,2*u,new Color(1,1,1,fade));
            Circle(hand.Beam,.025f,new Color(color.r,color.g,color.b,fade));
            Circle(hand.Shot,.035f+age*.18f,new Color(color.r,color.g,color.b,fade*.65f));
            Circle(hand.Shot,.02f,new Color(1,1,1,fade));
        }
    }
    GUIStyle Text(int size,Color color,TextAnchor align=TextAnchor.UpperLeft)
    {
        var s=new GUIStyle(GUI.skin.label){fontSize=size,alignment=align,wordWrap=true}; s.normal.textColor=color; return s;
    }
    bool Button(Rect r,string s,int size)=>GUI.Button(r,s,new GUIStyle(GUI.skin.button){fontSize=size});
    void OnGUI()
    {
        mousePosition=Event.current.mousePosition;
        if(mousePractice&&Event.current.type==EventType.MouseDown&&Event.current.button==0&&match.Phase==ShootingMatch.Stage.Playing) { mouseFire=true; Event.current.Use(); }
        float u=Mathf.Max(.55f,Screen.height/900f); int font=Mathf.RoundToInt(25*u),small=Mathf.RoundToInt(18*u);
        Box(new Rect(0,0,Screen.width,Screen.height),new Color(.025f,.045f,.1f));
        Texture2D background=silhouetteMode?silhouetteTexture:cameraTexture;
        if(background!=null)
        {
            GUI.color=silhouetteMode?Color.white:new Color(.6f,.67f,.8f,.85f);
            GUI.DrawTextureWithTexCoords(imageRect,background,mirror?new Rect(1,1,-1,-1):new Rect(0,1,1,-1)); GUI.color=Color.white;
        }
        Box(new Rect(0,0,Screen.width,100*u),new Color(.04f,.06f,.15f,.95f));
        for(int i=0;i<24;i++) Box(new Rect(i*Screen.width/24f,0,Screen.width/24f,8*u),i%2==0?new Color(.9f,.2f,.3f):new Color(1,.85f,.35f));
        GUI.Label(new Rect(25*u,15*u,Screen.width*.7f,40*u),"REACTOR / DRONE INVASION",Text(font,new Color(1,.88f,.4f)));
        var current=match.Current;
        GUI.Label(new Rect(25*u,55*u,Screen.width*.7f,35*u),current==null?"TAKE TURNS / 1 MINUTE EACH":current.Name+"   SCORE "+current.Score+"   HITS "+current.Hits,Text(small,Color.white));
        int seconds=match.Phase==ShootingMatch.Stage.Lobby?(int)ShootingMatch.RoundSeconds:Mathf.CeilToInt((float)match.Remaining);
        GUI.Label(new Rect(Screen.width-230*u,20*u,200*u,65*u),$"{seconds/60:00}:{seconds%60:00}",Text(Mathf.RoundToInt(43*u),seconds<=15?Color.red:Color.white,TextAnchor.MiddleRight));
        if(match.Phase==ShootingMatch.Stage.Playing)
        {
            foreach(var p in plates)
            {
                Vector2 pos=p.At(Elapsed),q=Pixel(pos);
                Color c=p.Points==500?new Color(1,.75f,.12f):p.Points==200?new Color(.2f,.85f,.8f):new Color(.95f,.25f,.4f);
                DrawEnemy(p,c,u,small);
            }
            for(int i=0;i<hands.Length;i++) DrawHand(hands[i],i,u,small);
            DrawBursts(u);
            if(combo>=3&&Time.unscaledTime<comboUntil)
                GUI.Label(new Rect(Screen.width*.32f,105*u,Screen.width*.36f,55*u),"COMBO x"+combo,Text(Mathf.RoundToInt(34*u),new Color(1,.75f,.25f),TextAnchor.MiddleCenter));
            if(match.Remaining<=10)
                GUI.Label(new Rect(Screen.width-310*u,90*u,280*u,45*u),"FINAL COUNTDOWN",Text(small,new Color(1,.4f,.35f),TextAnchor.MiddleRight));
            float flash=Time.unscaledTime-hitFlash;
            if(flash<.12f) Box(new Rect(0,0,Screen.width,Screen.height),new Color(0,.8f,1,(1-flash/.12f)*.035f));
            if(!mousePractice&&!HandVisible(hands[0])&&!HandVisible(hands[1]))
                GUI.Label(new Rect(Screen.width*.15f,Screen.height*.44f,Screen.width*.7f,100*u),"RAISE YOUR PALMS\nOpen either hand to charge your laser",Text(font,Color.white,TextAnchor.MiddleCenter));
            foreach(var e in effects)
            {
                Vector2 q=Pixel(e.Position); q.y-=(.7f-(e.Until-Time.unscaledTime))*70*u;
                GUI.Label(new Rect(q.x-90*u,q.y-65*u,180*u,50*u),e.Text,Text(font,e.Color,TextAnchor.MiddleCenter));
            }
        }
        Box(new Rect(0,Screen.height-78*u,Screen.width,78*u),new Color(.025f,.045f,.1f,.95f));
        GUI.Label(new Rect(20*u,Screen.height-72*u,Screen.width-40*u,65*u),(mousePractice?"PRACTICE / mouse + click":status)+"\nBOTH HANDS / Open = charge and fire. Close = stop. Aim carefully!",Text(small,new Color(.75f,.83f,.95f)));
        if(backgroundCountdown) GUI.Label(new Rect(0,Screen.height*.35f,Screen.width,150*u),"STEP OUT OF THE CAMERA\nBACKGROUND CAPTURE IN "+Mathf.CeilToInt(backgroundAt-Time.unscaledTime),Text(font,Color.yellow,TextAnchor.MiddleCenter));
        if(match.Phase!=ShootingMatch.Stage.Playing&&!backgroundCountdown) Panel(u,font,small);
    }
    void Panel(float u,int font,int small)
    {
        float w=Mathf.Min(Screen.width-40*u,740*u),h=Mathf.Min(Screen.height-170*u,700*u);
        Rect r=new Rect((Screen.width-w)/2,(Screen.height-h)/2,w,h); Box(r,new Color(.035f,.055f,.13f,.97f));
        float x=r.x+28*u,y=r.y+22*u,inner=w-56*u;
        if(match.Phase==ShootingMatch.Stage.Countdown)
        {
            GUI.Label(new Rect(x,y,inner,130*u),match.Current.Name+"\nGET READY",Text(font,Color.white,TextAnchor.MiddleCenter));
            GUI.Label(new Rect(x,y+140*u,inner,150*u),Mathf.CeilToInt((float)match.Countdown).ToString(),Text(Mathf.RoundToInt(95*u),Color.yellow,TextAnchor.MiddleCenter)); return;
        }
        if(match.Phase==ShootingMatch.Stage.Lobby)
        {
            GUI.Label(new Rect(x,y,inner,40*u),"DRONE INVASION / 1-MINUTE DUEL",Text(font,Color.yellow,TextAnchor.MiddleCenter)); y+=52*u;
            if(Button(new Rect(x,y,48*u,35*u),"-",font)) playerCount=Mathf.Max(2,playerCount-1);
            GUI.Label(new Rect(x+60*u,y,inner-120*u,35*u),playerCount+" PLAYERS / TAKE TURNS",Text(small,Color.white,TextAnchor.MiddleCenter));
            if(Button(new Rect(x+inner-48*u,y,48*u,35*u),"+",font)) playerCount=Mathf.Min(6,playerCount+1); y+=45*u;
            for(int i=0;i<playerCount;i++) { names[i]=GUI.TextField(new Rect(x,y,inner,32*u),names[i],20,new GUIStyle(GUI.skin.textField){fontSize=small}); y+=37*u; }
            mousePractice=GUI.Toggle(new Rect(x,y+8*u,inner*.5f,32*u),mousePractice," MOUSE PRACTICE",new GUIStyle(GUI.skin.toggle){fontSize=small});
            silhouetteMode=GUI.Toggle(new Rect(x+inner*.5f,y+8*u,inner*.5f,32*u),silhouetteMode," SILHOUETTE",new GUIStyle(GUI.skin.toggle){fontSize=small}); y+=45*u;
            GUI.Label(new Rect(x,y,inner,25*u),"REACH / "+(1/controlSpan).ToString("F1")+"x   (higher = less movement)",Text(small,Color.white)); y+=27*u;
            controlSpan=GUI.HorizontalSlider(new Rect(x,y,inner,24*u),controlSpan,1,.45f); y+=30*u;
            var sensor=GetComponent<AzureKinectInput>();
            if(sensor!=null)
            {
                GUI.Label(new Rect(x,y,inner,25*u),"SILHOUETTE RANGE / "+(sensor.silhouetteMaxDepth/1000f).ToString("F1")+"m",Text(small,Color.white)); y+=27*u;
                sensor.silhouetteMaxDepth=Mathf.RoundToInt(GUI.HorizontalSlider(new Rect(x,y,inner,24*u),sensor.silhouetteMaxDepth,1500,5000)); y+=27*u;
                if(Button(new Rect(x,y,inner,34*u),sensor.backgroundReady?"RETAKE EMPTY BACKGROUND (5s)":"CAPTURE EMPTY BACKGROUND (5s)",small)) { backgroundAt=Time.unscaledTime+5; backgroundCountdown=true; }
            }
            if(!backgroundCountdown&&Button(new Rect(x,r.yMax-60*u,inner,40*u),"START MATCH",font)) StartMatch(); return;
        }
        if(match.Phase==ShootingMatch.Stage.BetweenPlayers)
        {
            var p=match.Current;
            GUI.Label(new Rect(x,y,inner,70*u),p.Name+" / ROUND COMPLETE",Text(font,Color.yellow,TextAnchor.MiddleCenter));
            GUI.Label(new Rect(x,y+85*u,inner,150*u),$"SCORE {p.Score}\nHITS {p.Hits} / SHOTS {p.Shots}\nACCURACY {p.Accuracy:0.0}%",Text(font,Color.white,TextAnchor.MiddleCenter));
            GUI.Label(new Rect(x,y+250*u,inner,60*u),"NEXT: "+match.Players[match.PlayerIndex+1].Name+"\nStand in the same position",Text(small,Color.white,TextAnchor.MiddleCenter));
            GUI.Label(new Rect(x,y+315*u,inner,32*u),"BOTH HANDS ENABLED / SAME REACH SETTINGS",Text(small,Color.white));
            if(Button(new Rect(x,r.yMax-78*u,inner,50*u),"NEXT PLAYER READY",font)) { match.NextPlayer(); BeginTurn(); } return;
        }
        GUI.Label(new Rect(x,y,inner,45*u),"FINAL RESULTS",Text(font,Color.yellow,TextAnchor.MiddleCenter)); y+=60*u;
        var ranked=(ShootingMatch.Result[])match.Players.Clone(); Array.Sort(ranked,(a,b)=>b.Score.CompareTo(a.Score));
        int rank=0,last=int.MinValue;
        for(int i=0;i<ranked.Length;i++)
        {
            var p=ranked[i]; if(p.Score!=last) rank=i+1; last=p.Score;
            GUI.Label(new Rect(x,y,inner,52*u),$"#{rank} {p.Name} / {p.Score} PTS\n{p.Hits} HITS / {p.Shots} SHOTS / {p.Accuracy:0.0}%",Text(small,i==0?Color.yellow:Color.white)); y+=55*u;
        }
        GUI.Label(new Rect(x,r.yMax-103*u,inner,30*u),saveMessage,Text(Mathf.RoundToInt(14*u),Color.gray));
        if(Button(new Rect(x,r.yMax-65*u,inner,43*u),"PLAY AGAIN",font)) StartMatch();
    }
    void StartMatch() { var list=new string[playerCount]; Array.Copy(names,list,playerCount); match.Start(list); resultSaved=false; saveMessage=""; BeginTurn(); }
    void OnDestroy()
    {
        if(cameraTexture!=null) Destroy(cameraTexture); if(silhouetteTexture!=null) Destroy(silhouetteTexture);
        if(disc!=null) Destroy(disc); if(ring!=null) Destroy(ring);
        if(laserSound!=null) Destroy(laserSound); if(hitSound!=null) Destroy(hitSound); if(endSound!=null) Destroy(endSound);
    }
}
