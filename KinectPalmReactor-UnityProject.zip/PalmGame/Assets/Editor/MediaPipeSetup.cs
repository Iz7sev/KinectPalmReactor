using System;
using System.IO;
using System.Security.Cryptography;
using UnityEditor;
using UnityEditor.PackageManager;
using UnityEditor.PackageManager.Requests;
using UnityEngine;
using UnityEngine.Networking;

// Installs the prebuilt Windows-capable package through UPM, not the source-only Git repository.
[InitializeOnLoad]
public static class MediaPipeSetup
{
    const string PackageUrl="https://github.com/homuler/MediaPipeUnityPlugin/releases/download/v0.16.3/com.github.homuler.mediapipe-0.16.3.tgz";
    const string PackageHash="cc3e77a219e0b99618ae3be64c31a566197deedc69c1e136acf52d65d7cf2e79";
    const string ModelUrl="https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task";
    const string PackageFile="Dependencies/com.github.homuler.mediapipe-0.16.3.tgz";
    const string ModelFile="Assets/StreamingAssets/hand_landmarker.task";
    const string PendingKey="Starshot.MediaPipeInstallPending";
    static UnityWebRequest download;
    static AddRequest add;
    static bool downloadingModel;
    static string destination;
    static MediaPipeSetup() { EditorApplication.delayCall+=TryEnable; }
    static bool IsInstalled()
    {
        foreach(var package in UnityEditor.PackageManager.PackageInfo.GetAllRegisteredPackages())
            if(package.name=="com.github.homuler.mediapipe") return true;
        return false;
    }
    [MenuItem("Kinect Game/Install MediaPipe Hands")]
    public static void Install()
    {
        if(EditorApplication.isPlaying) { Debug.LogWarning("Stop Play before installing MediaPipe."); return; }
        if(download!=null||add!=null) return;
        Directory.CreateDirectory("Dependencies"); Directory.CreateDirectory("Assets/StreamingAssets");
        SessionState.SetBool(PendingKey,true);
        if(!File.Exists(ModelFile)) BeginDownload(ModelUrl,ModelFile,true);
        else InstallPackage();
    }
    static void BeginDownload(string url,string file,bool model)
    {
        destination=file; downloadingModel=model;
        download=UnityWebRequest.Get(url);
        download.downloadHandler=new DownloadHandlerFile(Path.GetFullPath(file+".part"));
        download.timeout=600; download.SendWebRequest();
        EditorApplication.update+=PollDownload;
    }
    static void PollDownload()
    {
        if(EditorUtility.DisplayCancelableProgressBar("Installing MediaPipe Hands",downloadingModel?"Downloading Google hand model":"Downloading MediaPipe Unity package (277 MB)",download.downloadProgress))
            download.Abort();
        if(!download.isDone) return;
        EditorApplication.update-=PollDownload; EditorUtility.ClearProgressBar();
        bool ok=download.result==UnityWebRequest.Result.Success;
        string error=download.error; download.Dispose(); download=null;
        if(!ok) { SessionState.SetBool(PendingKey,false); Debug.LogError("MediaPipe download failed: "+error+". Retry Kinect Game > Install MediaPipe Hands."); return; }
        string partial=destination+".part";
        if(!downloadingModel && Hash(partial)!=PackageHash)
        { SessionState.SetBool(PendingKey,false); Debug.LogError("MediaPipe package checksum mismatch. Package was not installed."); return; }
        File.Copy(partial,destination,true); File.Delete(partial);
        if(downloadingModel) InstallPackage(); else AddPackage();
    }
    static string Hash(string path)
    {
        using(var stream=File.OpenRead(path)) using(var sha=SHA256.Create())
            return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-","").ToLowerInvariant();
    }
    static void InstallPackage()
    {
        if(IsInstalled()) { AssetDatabase.Refresh(); TryEnable(); return; }
        if(File.Exists(PackageFile)&&Hash(PackageFile)==PackageHash) AddPackage();
        else BeginDownload(PackageUrl,PackageFile,false);
    }
    static void AddPackage()
    {
        add=Client.Add("file:"+Path.GetFullPath(PackageFile).Replace('\\','/'));
        EditorApplication.update+=PollPackage;
    }
    static void PollPackage()
    {
        if(!add.IsCompleted) return;
        EditorApplication.update-=PollPackage;
        if(add.Status==StatusCode.Failure) { Debug.LogError("MediaPipe package install failed: "+add.Error.message); SessionState.SetBool(PendingKey,false); }
        add=null; AssetDatabase.Refresh(); TryEnable();
    }
    [MenuItem("Kinect Game/Enable MediaPipe Hands")]
    public static void Enable() { SessionState.SetBool(PendingKey,true); TryEnable(); }
    static void TryEnable()
    {
        if(!SessionState.GetBool(PendingKey,false)||!IsInstalled()||!File.Exists(ModelFile)) return;
        var target=UnityEditor.Build.NamedBuildTarget.Standalone;
        string symbols=PlayerSettings.GetScriptingDefineSymbols(target);
        if(Array.IndexOf(symbols.Split(';'),"MEDIAPIPE_HANDS")<0)
            PlayerSettings.SetScriptingDefineSymbols(target,string.IsNullOrEmpty(symbols)?"MEDIAPIPE_HANDS":symbols+";MEDIAPIPE_HANDS");
        SessionState.SetBool(PendingKey,false);
        AssetDatabase.SaveAssets();
        Debug.Log("MediaPipe Hands enabled. Open Assets/Game.unity, press Play, and make a finger gun.");
    }
}
